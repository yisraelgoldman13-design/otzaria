import 'dart:io';

/// Gets platform type.
String getPlatformType() {
  return Platform.operatingSystem;
}
